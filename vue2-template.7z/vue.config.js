module.exports = {
  publicPath: process.env.VUE_APP_BASE_URL,
  
}